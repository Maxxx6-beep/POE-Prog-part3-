﻿namespace RaceDayApi.Models
{

        public class Category
        {
            public int CategoryID { get; set; }
            public int EventID { get; set; }

            public string CategoryName { get; set; } = "";
            public string CategoryType { get; set; } = "";
            public double Distance { get; set; }

            public Event? Event { get; set; }
        }
    }

