﻿namespace RaceDayApi.Models
{
    public class Route
    {
        public int RouteID { get; set; }
        public int EventID { get; set; }

        public string RouteName { get; set; } = "";
        public double Distance { get; set; }
        public string Description { get; set; } = "";

        public Event? Event { get; set; }
    }
}
   

