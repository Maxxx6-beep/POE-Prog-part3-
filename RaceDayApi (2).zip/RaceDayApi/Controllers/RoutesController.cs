﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoutesController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public RoutesController(RaceDayContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<RaceDayApi.Models.Route>>> GetRoutes()
        {
            return await _context.Routes.ToListAsync();
        }

        [HttpPost]
        public async Task<IActionResult> AddRoute(RaceDayApi.Models.Route newRoute)
        {
            _context.Routes.Add(newRoute);
            await _context.SaveChangesAsync();

            return Ok(" successfully added Route.");
        }
    }
}
